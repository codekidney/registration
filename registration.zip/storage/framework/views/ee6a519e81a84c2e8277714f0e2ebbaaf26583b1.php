<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    Profile
                    <a href="<?php echo e(route('user_edit')); ?>" class="btn btn-primary float-right">Edit</a>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <tbody>
                            <tr>
                                <th scope="row">First Name</th>
                                <td><?php echo e($user->first_name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Last Name</th>
                                <td><?php echo e($user->last_name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">E-mail</th>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Pesel</th>
                                <td><?php echo e($user->pesel); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Języki programowania</th>
                                <td>
                                    <?php $__currentLoopData = $user->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="lang"><?php echo e($lang->name); ?></span>, 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kamil\Learning\Laravel\registration\resources\views/user/index.blade.php ENDPATH**/ ?>